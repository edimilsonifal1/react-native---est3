import React from 'react';
import {Text, View } from 'react-native';

export default function App() {
  return (
    <View>
      <View>
        <Text>Edimilson Torres</Text>
      </View>
      <View>
        <Text>Taxi Driver, Clube da Luta, The Godfather</Text>
      </View>
      <Text>Counting Stars, RAPTURE, Warning</Text>
    </View>
  );
}